package retail;

public class Retail {

    public static void main(String[] args) {

    }

}
