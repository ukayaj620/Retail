package models;

public enum OperasiCRUD {
    INSERT, UPDATE, DELETE, QUERY
}